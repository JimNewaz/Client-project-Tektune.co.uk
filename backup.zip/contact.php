<?php

if(isset($_POST["email_subscribe_form"])) {
	$email = $_POST["email"];
	$email = mb_convert_encoding($email, "UTF-8", "UTF-8");
	$email = htmlentities($email, ENT_QUOTES, "UTF-8");

    $email_to_len = "
    <html>
    <body>
    <p>Hi Roarcuss,</p><br>
    <p>You have received a new subscriber to your website news subscription service</p><br>
    <p>Email:$email</p>
    </body>
    </html>
    ";

    $email_to_customer = "
    <html>
    <body>
    <p>Hi $email,</p><br>
    <p>A newsletter subscription request for this email address was received. </p><br>
    <p>Thank You<br>Roarcuss Technologies</p>
    </body>
    </html>
    ";

    $headers = "From: info@roarcuss.co.uk\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";


	mail("info@roarcuss.co.uk", "New newsletter subscription request", $email_to_len, $headers); // Send email to Len
	mail($email, "Welcome to our newsletter", $email_to_customer, $headers); // Send email to customer

    $subscribed = true;

    //mail("stefan.stoj@yahoo.com", "New newsletter subscription request", $email_to_len, $headers); // Send email to Len
    //mail("stefan.stoj@yahoo.com", "Welcome to our newsletter", $email_to_customer, $headers); // Send email to customer

}
?>
<!DOCTYPE html>

<html lang="en">

<head>
<link rel="shortcut icon" href="favicon-32x32.png">

<title> TekTune </title>

<meta charset="utf-8"/>

<link rel="stylesheet" href="normalize.css"/>

<link rel="stylesheet" href="styles.css"/>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>

</head>



<body>
    <button onclick="topFunction()" id="gototop" title="Go to top"><img src="upload-up-arrow-symbol-in-circular-outlined-button.png" alt="" title="" /></button>

    <div id="myModal2" class="modal">

        <!-- Modal content -->

        <div class="modal-content">

            <span class="close">&times;</span>


            <div id="terms-txt">

                Your subscription was successful! Within a few minutes you will also receive a confirmation email welcoming you to our monthly newsletter.
            </div>

        </div>

    </div>
    <script>
        $( function() {
            <?php if($subscribed) echo "$('#myModal2').css('display', 'block')"; ?>


            var modal2 = document.getElementById('myModal2');
            var span2 = document.getElementsByClassName("close")[0]; // Get the <span> element that closes the modal

            // When the user clicks the button, open the modal
            span2.onclick = function() {
                modal2.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal2) {
                    modal2.style.display = "none";
                }
            }
        });
    </script>



    </div>

<header>

<div id="opening-hours">

<h2>Opening Hours</h2>

<p>

<strong>Monday - Saturday:</strong> 9:00AM - 10:00PM

<br>

<strong>Sunday:</strong> 9:00AM - 9:00PM



</P>

</div>


<div id="Contact-Details">

<h2>Contact Details</h2>

<p>

<strong>Phone:</strong> 0800 448 0962

<br>

<strong>Email:</strong> sales@tektune.co.uk



</P>

</div>



<img id="roarlogo" src="logo3.png" alt="TekTune"/>





<nav>

<ul id="nav-buttons">

<a href="index.html"> <button class="button1"> HOME  </button> </a>

<a href="services.html"> <button class="button1"> SERVICES  </button> </a>

<a href="terms.html"> <button class="button1"> TERMS  </button> </a>

<a href="about.html"> <button class="button1"> ABOUT  </button> </a>

<a href="contact.php"> <button class="button1"> CONTACT </button> </a>




</ul>

</nav>

<br>
<br>
<br>



<div id="namebox5">

<h1> We are based in Ely Cambridgeshire </h1>

<br>

<p>
<br>

<strong> Opening Hours</strong> <br>

Monday - Saturday: 9:00AM - 10:00PM<br>

Sunday: : 9:00AM - 9:00PM<br>

</P>

<br>

<h1>Contact us</h1>

<br>

<p>

<strong> Phone:</strong> 0800 448 0962 <br>

<strong> Email:</strong> sales@tektune.co.uk

</P>

<br>





<br>

<br>

</div>

<br>

<br>





</form>



<br>

<br>



<footer>

<ul id="nav-buttons2"> <h1 id="footer-heading"> Information </h1>

<li> <a href="index.html"> Home </a> </li>

<li> <a href="services.html"> Services </a> </li>

<li> <a href="terms.html"> Terms </a> </li>

<li> <a href="about.html"> About </a> </li>

<li> <a href="contact.php"> Contact </a> </li>


</ul>


<br>

<br>





<h1 id="footer-heading"> About Us</h1>

<br>



<p>

TekTune is a UK based remapping company <br> Our goal is to supply quality remapping solutions

</p>

</footer>



<div id="copyright">

© Copyright 2022 TekTune. All rights reserved.

</div>


<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("gototop").style.display = "block";
    } else {
        document.getElementById("gototop").style.display = "none";
    }
}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
</body>

</html>